# Student Performance Prediction & Academic Risk Analysis

A BCA ML mini-project that predicts a student's expected performance score
(0–100) and classifies them into a **Low / Medium / High** academic risk
category, based on attendance, internal marks, assignment scores, previous
CGPA, study habits, and backlogs.

## Project structure

```
student-performance-project/
│
├── app.py                # Front end (Streamlit UI)
├── train_model.py        # Back end (data cleaning + ML training)
├── generate_data.py       # Creates the sample dataset (optional, one-time)
├── student_data.csv      # Dataset (500 sample student records)
├── student_model.pkl     # Trained model (created by train_model.py)
├── requirements.txt
└── README.md
```

## How it works

- **Back end (`train_model.py`)**
  - Loads `student_data.csv`
  - Cleans the data (missing values, out-of-range values, encoding)
  - Trains a `RandomForestRegressor` to predict `Final_Performance`
  - Trains a `RandomForestClassifier` to predict `Academic_Risk`
  - Prints evaluation metrics (MAE, R², accuracy, classification report)
  - Saves both models + encoders into `student_model.pkl`

- **Front end (`app.py`)**
  - Streamlit form to enter a student's details
  - Loads `student_model.pkl` and runs both models on the input
  - Shows the predicted performance score, risk category, and a
    probability breakdown chart
  - Sidebar shows the model's accuracy/error metrics for transparency

## Setup & run

```bash
# 1. Create and activate a virtual environment (recommended)
python -m venv venv
venv\Scripts\activate          # Windows
source venv/bin/activate       # macOS/Linux

# 2. Install dependencies
pip install -r requirements.txt

# 3. (Optional) regenerate the sample dataset
python generate_data.py

# 4. Train the models — creates student_model.pkl
python train_model.py

# 5. Launch the web app
streamlit run app.py
```

The app opens in your browser (usually at `http://localhost:8501`).

## Using your own real dataset

`generate_data.py` produces a **synthetic** dataset so the project runs
out of the box. For a real submission, replace `student_data.csv` with
your institution's actual data, keeping the same column names:

| Column              | Type        | Description                          |
|---------------------|-------------|---------------------------------------|
| Student_Name        | text        | not used as a model feature           |
| Attendance          | 0–100       | attendance percentage                 |
| Internal_Marks      | 0–50        | internal assessment marks             |
| Assignment_Score    | 0–20        | assignment marks                      |
| Previous_CGPA       | 0–10        | previous semester CGPA                |
| Study_Hours         | number      | average study hours per day           |
| Backlogs            | 0, 1, 2, 3+ | number of active backlogs             |
| Extra_Curricular    | Yes/No      | participates in extra-curriculars     |
| Final_Performance   | 0–100       | target: actual performance/marks      |
| Academic_Risk       | text        | target: Low/Medium/High Risk label    |

Then just re-run `python train_model.py` — the app automatically picks up
the newly trained model.

## Notes for your report

- Both models are `RandomForest` (regressor + classifier) from
  scikit-learn — genuinely trained, not hard-coded predictions.
- Metrics printed by `train_model.py` (MAE, R², accuracy, precision/recall)
  are good material for your project report/viva.
- Feature importance is printed too, useful for explaining *why* the model
  predicts what it predicts.

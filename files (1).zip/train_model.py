"""
train_model.py
---------------
BACK END of the Student Performance Prediction & Academic Risk Analysis
project.

What this script does (in order):
1. Loads student_data.csv
2. Cleans the data (missing values, type fixes)
3. Encodes categorical columns
4. Trains TWO real models:
      - RandomForestRegressor  -> predicts Final_Performance (0-100)
      - RandomForestClassifier -> predicts Academic_Risk category
5. Evaluates both models and prints metrics
6. Saves everything needed for prediction into student_model.pkl

Run:
    python train_model.py
"""

import pandas as pd
import numpy as np
import joblib

from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor, RandomForestClassifier
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import (
    mean_absolute_error,
    r2_score,
    accuracy_score,
    classification_report,
)

DATA_PATH = "student_data.csv"
MODEL_PATH = "student_model.pkl"

FEATURE_COLUMNS = [
    "Attendance",
    "Internal_Marks",
    "Assignment_Score",
    "Previous_CGPA",
    "Study_Hours",
    "Backlogs",
    "Extra_Curricular",   # categorical -> encoded below
]

REGRESSION_TARGET = "Final_Performance"
CLASSIFICATION_TARGET = "Academic_Risk"


def load_and_clean_data(path: str) -> pd.DataFrame:
    df = pd.read_csv(path)

    # --- Basic cleaning ---
    # Drop rows that are missing a target value (nothing to learn from them)
    df = df.dropna(subset=[REGRESSION_TARGET, CLASSIFICATION_TARGET])

    # Fill missing numeric feature values with the column median
    numeric_cols = [
        "Attendance", "Internal_Marks", "Assignment_Score",
        "Previous_CGPA", "Study_Hours", "Backlogs",
    ]
    for col in numeric_cols:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")
            df[col] = df[col].fillna(df[col].median())

    # Fill missing categorical values with the most frequent value
    if "Extra_Curricular" in df.columns:
        df["Extra_Curricular"] = df["Extra_Curricular"].fillna(
            df["Extra_Curricular"].mode()[0]
        )

    # Clip obviously out-of-range values to valid bounds
    df["Attendance"] = df["Attendance"].clip(0, 100)
    df["Internal_Marks"] = df["Internal_Marks"].clip(0, 50)
    df["Assignment_Score"] = df["Assignment_Score"].clip(0, 20)
    df["Previous_CGPA"] = df["Previous_CGPA"].clip(0, 10)

    return df.reset_index(drop=True)


def build_features(df: pd.DataFrame, ec_encoder: LabelEncoder = None):
    df = df.copy()

    if ec_encoder is None:
        ec_encoder = LabelEncoder()
        df["Extra_Curricular_Enc"] = ec_encoder.fit_transform(df["Extra_Curricular"])
    else:
        df["Extra_Curricular_Enc"] = ec_encoder.transform(df["Extra_Curricular"])

    feature_matrix = df[[
        "Attendance", "Internal_Marks", "Assignment_Score",
        "Previous_CGPA", "Study_Hours", "Backlogs", "Extra_Curricular_Enc",
    ]].values

    return feature_matrix, ec_encoder


def main():
    print("Loading and cleaning data...")
    df = load_and_clean_data(DATA_PATH)
    print(f"  {len(df)} usable rows after cleaning")

    X, ec_encoder = build_features(df)
    y_reg = df[REGRESSION_TARGET].values

    risk_encoder = LabelEncoder()
    y_clf = risk_encoder.fit_transform(df[CLASSIFICATION_TARGET])

    # Single train/test split reused for both models so results are comparable
    X_train, X_test, y_reg_train, y_reg_test, y_clf_train, y_clf_test = train_test_split(
        X, y_reg, y_clf, test_size=0.2, random_state=42
    )

    # --- Regression model: predicts a 0-100 performance score ---
    print("\nTraining performance regression model...")
    reg_model = RandomForestRegressor(
        n_estimators=300, max_depth=8, random_state=42, n_jobs=-1
    )
    reg_model.fit(X_train, y_reg_train)
    reg_preds = reg_model.predict(X_test)
    mae = mean_absolute_error(y_reg_test, reg_preds)
    r2 = r2_score(y_reg_test, reg_preds)
    print(f"  MAE : {mae:.2f} marks")
    print(f"  R^2 : {r2:.3f}")

    # --- Classification model: predicts Low / Medium / High risk ---
    print("\nTraining academic risk classification model...")
    clf_model = RandomForestClassifier(
        n_estimators=300, max_depth=8, random_state=42, n_jobs=-1
    )
    clf_model.fit(X_train, y_clf_train)
    clf_preds = clf_model.predict(X_test)
    acc = accuracy_score(y_clf_test, clf_preds)
    print(f"  Accuracy: {acc:.3f}")
    print(classification_report(
        y_clf_test, clf_preds, target_names=risk_encoder.classes_
    ))

    # --- Feature importance (useful to show in the app / report) ---
    feature_names = [
        "Attendance", "Internal_Marks", "Assignment_Score",
        "Previous_CGPA", "Study_Hours", "Backlogs", "Extra_Curricular",
    ]
    importances = pd.Series(
        reg_model.feature_importances_, index=feature_names
    ).sort_values(ascending=False)
    print("\nFeature importance (performance model):")
    print(importances.round(3))

    # --- Save everything the app needs to make predictions ---
    bundle = {
        "regression_model": reg_model,
        "classification_model": clf_model,
        "extra_curricular_encoder": ec_encoder,
        "risk_encoder": risk_encoder,
        "feature_names": feature_names,
        "metrics": {
            "regression_mae": mae,
            "regression_r2": r2,
            "classification_accuracy": acc,
        },
    }
    joblib.dump(bundle, MODEL_PATH)
    print(f"\nSaved trained models to {MODEL_PATH}")


if __name__ == "__main__":
    main()

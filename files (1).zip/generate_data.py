"""
generate_data.py
-----------------
Generates a synthetic but realistic student academic dataset for the
Student Performance Prediction & Academic Risk Analysis project.

Run this once to create student_data.csv. In a real project you would
replace this with your actual institutional data (exported as CSV with
the same column names), but this script gives you a working dataset
with genuine statistical relationships (not random noise) so the model
trained on it behaves sensibly.
"""

import numpy as np
import pandas as pd

np.random.seed(42)

N = 500  # number of students

names = [f"Student_{i+1}" for i in range(N)]

# --- Base academic behaviour (independent variables) ---
attendance = np.clip(np.random.normal(78, 12, N), 40, 100)
study_hours = np.clip(np.random.normal(3.2, 1.5, N), 0, 10)
previous_cgpa = np.clip(np.random.normal(6.8, 1.3, N), 3.0, 10.0)
assignment_score = np.clip(
    np.random.normal(14, 3.5, N) + (study_hours - 3.2) * 0.8, 0, 20
)
internal_marks = np.clip(
    np.random.normal(30, 8, N) + (attendance - 78) * 0.15 + (study_hours - 3.2) * 1.2,
    0, 50
)
extra_curricular = np.random.choice(["Yes", "No"], size=N, p=[0.35, 0.65])
backlogs = np.random.choice([0, 1, 2, 3], size=N, p=[0.6, 0.25, 0.1, 0.05])

# --- Target: final performance score (0-100), built from a genuine
#     weighted relationship plus realistic noise ---
final_performance = (
    0.25 * attendance
    + 0.9 * internal_marks          # internal_marks is out of 50 -> scaled contribution
    + 1.1 * assignment_score        # out of 20
    + 3.0 * previous_cgpa           # out of 10
    + 1.5 * study_hours
    - 4.0 * backlogs
    + np.where(extra_curricular == "Yes", 1.5, 0)
    + np.random.normal(0, 5, N)     # natural noise
)

# Rescale into a believable 0-100 percentage
final_performance = (final_performance - final_performance.min()) / (
    final_performance.max() - final_performance.min()
) * 100
final_performance = np.round(np.clip(final_performance, 0, 100), 2)


def risk_label(score, att, bl):
    if score < 45 or att < 55 or bl >= 2:
        return "High Risk"
    elif score < 65 or att < 70 or bl == 1:
        return "Medium Risk"
    else:
        return "Low Risk"


academic_risk = [
    risk_label(s, a, b) for s, a, b in zip(final_performance, attendance, backlogs)
]

df = pd.DataFrame({
    "Student_Name": names,
    "Attendance": np.round(attendance, 1),
    "Internal_Marks": np.round(internal_marks, 1),
    "Assignment_Score": np.round(assignment_score, 1),
    "Previous_CGPA": np.round(previous_cgpa, 2),
    "Study_Hours": np.round(study_hours, 1),
    "Backlogs": backlogs,
    "Extra_Curricular": extra_curricular,
    "Final_Performance": final_performance,
    "Academic_Risk": academic_risk,
})

df.to_csv("student_data.csv", index=False)
print(f"Generated student_data.csv with {len(df)} rows")
print(df["Academic_Risk"].value_counts())

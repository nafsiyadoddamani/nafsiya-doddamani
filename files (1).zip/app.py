"""
app.py
------
FRONT END of the Student Performance Prediction & Academic Risk Analysis
project, built with Streamlit.

Run:
    streamlit run app.py

Make sure you have already run `python train_model.py` at least once so
that student_model.pkl exists.
"""

import os
import joblib
import numpy as np
import pandas as pd
import streamlit as st

MODEL_PATH = "student_model.pkl"

st.set_page_config(
    page_title="Student Performance & Academic Risk Predictor",
    page_icon="🎓",
    layout="centered",
)


@st.cache_resource
def load_model_bundle():
    if not os.path.exists(MODEL_PATH):
        return None
    return joblib.load(MODEL_PATH)


def risk_color(risk: str) -> str:
    return {
        "Low Risk": "🟢",
        "Medium Risk": "🟡",
        "High Risk": "🔴",
    }.get(risk, "⚪")


bundle = load_model_bundle()

st.title("🎓 Student Performance Prediction & Academic Risk Analysis")
st.write(
    "Enter a student's academic details below to predict their expected "
    "performance score and academic risk category."
)

if bundle is None:
    st.error(
        "No trained model found. Please run `python train_model.py` first "
        "to generate `student_model.pkl`, then restart this app."
    )
    st.stop()

reg_model = bundle["regression_model"]
clf_model = bundle["classification_model"]
ec_encoder = bundle["extra_curricular_encoder"]
risk_encoder = bundle["risk_encoder"]
metrics = bundle["metrics"]

with st.sidebar:
    st.header("Model info")
    st.metric("Performance model R²", f"{metrics['regression_r2']:.2f}")
    st.metric("Performance model MAE", f"{metrics['regression_mae']:.1f} marks")
    st.metric("Risk model accuracy", f"{metrics['classification_accuracy']*100:.0f}%")
    st.caption(
        "Metrics are computed on a held-out test split during training. "
        "Retrain with more/real data to improve them."
    )

st.subheader("Student details")

student_name = st.text_input("Student name", placeholder="e.g. Priya Sharma")

col1, col2 = st.columns(2)
with col1:
    attendance = st.slider("Attendance (%)", 0, 100, 75)
    internal_marks = st.slider("Internal marks (out of 50)", 0, 50, 30)
    assignment_score = st.slider("Assignment score (out of 20)", 0, 20, 14)
    study_hours = st.slider("Average study hours/day", 0.0, 10.0, 3.0, 0.5)

with col2:
    previous_cgpa = st.slider("Previous semester CGPA (out of 10)", 0.0, 10.0, 7.0, 0.1)
    backlogs = st.selectbox("Number of active backlogs", [0, 1, 2, 3], index=0)
    extra_curricular = st.radio("Participates in extra-curricular activities?", ["Yes", "No"])

predict_clicked = st.button("🔮 Predict Performance", type="primary", use_container_width=True)

if predict_clicked:
    ec_encoded = ec_encoder.transform([extra_curricular])[0]

    features = np.array([[
        attendance,
        internal_marks,
        assignment_score,
        previous_cgpa,
        study_hours,
        backlogs,
        ec_encoded,
    ]])

    predicted_score = float(reg_model.predict(features)[0])
    predicted_score = round(max(0, min(100, predicted_score)), 1)

    risk_pred_encoded = clf_model.predict(features)[0]
    risk_label = risk_encoder.inverse_transform([risk_pred_encoded])[0]

    risk_proba = clf_model.predict_proba(features)[0]
    risk_classes = risk_encoder.classes_

    st.divider()
    display_name = student_name if student_name.strip() else "This student"
    st.subheader(f"Results for {display_name}")

    r1, r2 = st.columns(2)
    with r1:
        st.metric("Predicted Performance Score", f"{predicted_score} / 100")
    with r2:
        st.metric("Academic Risk", f"{risk_color(risk_label)} {risk_label}")

    st.write("**Risk probability breakdown:**")
    proba_df = pd.DataFrame({
        "Risk Category": risk_classes,
        "Probability": np.round(risk_proba * 100, 1),
    }).sort_values("Probability", ascending=False)
    st.bar_chart(proba_df.set_index("Risk Category"))

    if risk_label == "High Risk":
        st.error(
            "⚠️ This student is at **high academic risk**. Recommend immediate "
            "attention: mentoring, attendance follow-up, and remedial classes."
        )
    elif risk_label == "Medium Risk":
        st.warning(
            "This student shows **moderate risk**. Consider monitoring "
            "attendance and offering extra academic support."
        )
    else:
        st.success(
            "This student is currently **on track** with low academic risk."
        )

    with st.expander("See input summary"):
        st.json({
            "Attendance (%)": attendance,
            "Internal Marks": internal_marks,
            "Assignment Score": assignment_score,
            "Previous CGPA": previous_cgpa,
            "Study Hours/day": study_hours,
            "Backlogs": backlogs,
            "Extra Curricular": extra_curricular,
        })

st.divider()
st.caption(
    "Built with Streamlit + scikit-learn · Random Forest models trained on "
    "student_data.csv"
)
